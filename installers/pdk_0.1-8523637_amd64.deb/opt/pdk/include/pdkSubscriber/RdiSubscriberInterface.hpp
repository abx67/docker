#pragma once

#include "pdk_RadarDetectionImage.pb.h"
#include "pdk_RadarStatus.pb.h"
#include <functional>

namespace PDK
{
  class CRdiInterface
  {
  public:
    static void SetRDICallback(std::function<void(const class pb::PDK::RadarDetectionImage*)> callback);
    static void SetRadarStatusCallback(std::function<void(const class pb::PDK::RadarStatus*)> callback);
    static std::string GetVersion();
  };
} // namespace PDK
